class OpdDepartment:
    
    def __init__(self,national_health_number, OPD_number, patient_name, gender, age, date_of_birth, tele_number, date,weight, height, temperature):
        self.national_health_number = national_health_number
        self.OPD_number = OPD_number
        self.patient_name = patient_name
        self.gender = gender
        self.age = age
        self.date_of_birth = date_of_birth
        self.tele_number = tele_number
        self.date = date
        self.weight = weight
        self.height = height
        self.temperature = temperature
        self.patient_details = [(national_health_number, OPD_number, patient_name, gender, age, date_of_birth, tele_number, date,weight, height, temperature)]
    
    
    def update_patient_info(self,new_age, new_weight,new_height,new_temperature):
        self.age = new_age
        self.weight =new_weight
        self.height = new_height
        self.temperature = new_temperature
        
    
    
    def saving_details (self):
        empty =  False
        try:
            with open("Patient File.csv", "r") as data:
                if len(data.readline().strip()) == 0:
                    empty = True
        except:
            with open("Patient File.csv", "w") as data:
                empty = True
        with open("Patient File.csv", "a") as patients_file:
            if empty:
                patients_file.write("{:35}, {:20}, {:15}, {:25}, {:20}, {:15}, {:15}\n".format ("DATE", "PATIENT NAME", "OPD NUMBER", "NATIONAL HEALTH NUMBER", "DATE OF BIRTH", "GENDER", "TELEPHONE NUMBER"))
            for i in self.patient_details:
                patients_file.write("{:35}, {:<20}, {:<15}, {:<25}, {:<20}, {:<15}, {:<15}\n".format(i[7],i[2], i[1], i[0], i[5], i[3], i[6]))
            return '''Your details have been saved to our system'''
       
       
    def health_condition(self, nurse_on_duty,symptons, likely_ailment, consulting_room_number):
        self.nurse_on_duty = nurse_on_duty
        self.symptons = symptons 
        self.likely_ailment = likely_ailment
        self.consulting_room_number = consulting_room_number
        print(self.hospital_unit())
        
    
    def hospital_unit(self):
        if self.consulting_room_number == 1:
            return f"{self.patient_name},Go for treatment at the child and maternity unit"
        elif self.consulting_room_number == 2:
            return f"{self.patient_name},Go to the laboratory for some tests"
        elif self.consulting_room_number ==3:
            return f"{self.patient_name},Go to the cardiac care unit"
        elif self.consulting_room_number == 4:
            return f"{self.patient_name},Go to intensive care unit"
        elif self.consulting_room_number == 5:
            return f"{self.patient_name},Go to dressing room "
        elif self.consulting_room_number == 6:
            return f"{self.patient_name}, Go to the eye clinic"
        elif self.consulting_room_number == 7:
            return f"{self.patient_name},Go to the dental clinic"
        elif self.consulting_room_number == 8:
            return f"{self.patient_name},Go to reproductive health unit"
        else:
            return f"{self.patient_name},Go to general consulting room"
    
    def feedback_from_doctor(self):
        self.report = input("What sickness is the patient suffering from? \n")
        self.feedback = input("Will the patient be admitted, given prescription or discharged\n")
        if self.feedback.upper()== "ADMITTED":
            print(Treatment.in_patient_unit(self))
        elif self.feedback.upper() == "GIVEN PRESCRIPTION":
            print(Treatment.dispensary())
        elif self.feedback.upper() == "DISCHARGED":
            print(Treatment.finance_unit())
        else:
            print("invalid response")
            self.feedback_from_doctor()
            
                        
    def __str__(self):
        return f'''Date: {self.date} \n Patient:{self.patient_name}\n Date of birth:{self.date_of_birth}\n Age:{self.age}years\n Telephone number:{self.tele_number}\n OPD number: {self.OPD_number}
 Gender:{self.gender}\n Weight: {self.weight}kg \n Height: {self.height}cm\n Temperature: {self.temperature}*C'''
    


class Treatment:

    def dispensary():
        prescription = int(input("How many medicines are you prescribing to the patient: "))
        print("Please provide the various medicines and the right dosages.")
        medicine_list = []
        for i in range(prescription):
            medicine_name = input("What is the name of the medicine: ")
            dosage = input("How many doses of this medicine should the patient take: ")
            medicine_list.append((medicine_name,dosage))
        return f'''Please these are your medicine and how you should take them {medicine_list}.kindly take them as carefully written and get well well soon'''
        
    
    def in_patient_unit(patient):
        for person in patient.patient_details:
            if  person[3] == "female":
                room_type = input("Would you like a regular ward or a VIP ward? \n")
                room_number = input("Dear official, which room is available\n")
                return f'''Dear {person[2]}, you have been assigned to room number {room_number} in the {room_type} female ward. Get well soon!!'''
            elif person[3] == "male":
                room_type = input("Would you like a regular ward or a VIP ward? \n")
                room_number = input("Dear official, which room is available\n")
                return f'''Dear {person[2]}, you have been assigned to room number {room_number} in the {room_type} male ward. Get well soon!!'''    

    
    def finance_unit():
        print("Hello, welcome to the finance unit of this health institution")
        room_type = input("Were you admitted to the VIP or regular patient ward \n")
        days_spent = int(input("For how many days were you admitted in the hospital?\n"))
        feeding  = input("Were you relying on the catering services in the hospital for feeding?\n")
        
        if room_type.upper() == "VIP" and feeding.upper() == "YES":
            bill = 100  * days_spent
            return f'''Your total bill is GHC{bill}, kindly make payments to the cashier and take good care of yourself'''
        elif room_type.upper() == "VIP" and feeding.upper() == "NO":
            bill = 70  * days_spent
            return f'''Your total bill is GHC{bill}, kindly make payments to the cashier and take good care of yourself'''
        
        elif room_type.upper() == "REGULAR" and feeding.upper() == "YES":
            bill = 50  * days_spent
            return f'''Your total bill is GHC{bill}, kindly make payments to the cashier and take good care of yourself'''
        elif room_type.upper() == "REGULAR" and feeding.upper() == "NO":
            bill = 30  * days_spent
            return f'''Your total bill is GHC{bill}, kindly make payments to the cashier and take good care of yourself'''




if __name__ == "__main__":
        
    patient1= OpdDepartment(45812, 678, "Abena", "female", 64, " 11th December 1994", "0248963178", "26th November 2021", 88, 136, 36.5)
    patient2 = OpdDepartment (79588,888,"Yaw", "male", 45, "7th June 1996", "0261051053","26th November 2021", 95, 195, 35.2)
    patient3 = OpdDepartment (45814, 698, "Lovelace", "female", 16, " 20th October 2003", "0248978945", "20th November 2021", 87, 132, 34.5)
    patient4 = OpdDepartment (45812,123, "Aba", "female", 24, " 2nd October 2004", "0249785634", "13th November 2021", 64, 136, 35.5)
    patient5 = OpdDepartment (45812, 333, "Kirklyn", "male", 74, " 10th January 1999", "0558763915", "11th November 2021", 63, 140, 37.5)
    patient6 = OpdDepartment (45812, 456, "Kwabs", "male", 56, " 9th May 2020", "0267894567", "4th November 2021", 92, 145, 33.5)
    patient7 = OpdDepartment (45812, 989, "Gerald", "male", 17, " 21st July 2002", "0248975618", "2nd November 2021", 78, 150, 36.5)
    patient8 = OpdDepartment (45812, 414, "Promise", "female", 23, " 11th June 2016", "0247899548", "1st November 2021", 93, 188, 35.5)
    patient9 = OpdDepartment (45812, 224, "Zwennes", "female", 43, " 7th September 2017", "0554896317", "19th November 2021", 54, 175, 34.5)
    patient10 = OpdDepartment (45812, 558, "Adamkie", "female", 99, " 6th June 2008", "0279993178", "24th November 2021", 56, 156, 36.8)    
    #print(patient1)
    
    #patient1.update_patient_info(26, 76, 145, 35.2)
    #print(patient1)
#     
    patient7.health_condition("Angela", "vomitting",  "Pregnant", 5)
    
    patient1.feedback_from_doctor()
#   patient2.feedback_from_doctor()
    

#     print(patient1)
#     print()
#     print(patient2)
#     print()
#     print(patient3)
#     print()
#     print(patient4)
#     print()
#     print(patient5)
#     print()
#     print(patient6)
#     print()
#     print(patient7)
#     print()
#     print(patient8)
#     print()
#     print(patient9)
#     print()
#     print(patient10)
#     
#     print(patient1.saving_details())
#     print(patient2.saving_details())
#     print(patient3.saving_details())
#     print(patient4.saving_details())
#     print(patient5.saving_details())
#     print(patient6.saving_details())
#     print(patient7.saving_details())
#     print(patient8.saving_details())
#     print(patient9.saving_details())
#     print(patient10.saving_details())
  
  
      